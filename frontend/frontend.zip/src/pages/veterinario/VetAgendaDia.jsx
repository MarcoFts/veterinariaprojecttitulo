// src/pages/veterinario/VetAgendaDia.jsx
import { useEffect, useMemo, useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight } from "lucide-react";
import LayoutVet from "../../components/layout/LayoutVet";
import SlotCard from "../../components/agenda/SlotCard";
import ModalCrearCita from "../../components/modals/ModalCrearCita";
import ModalReprogramarCita from "../../components/modals/ModalReprogramarCita";
import {
  me as getUserProfile,
  getDisponibilidad,
  getCitas,
  confirmarCita,
} from "../../services/api";

import dayjs from "dayjs";
import "dayjs/locale/es";
dayjs.locale("es");

// hoy YYYY-MM-DD
const todayStr = () => dayjs().format("YYYY-MM-DD");

// suma minutos a "HH:MM" y devuelve "HH:MM"
const sumarMinutos = (horaStr, minutos) => {
  const [h, m] = horaStr.split(":").map(Number);
  const d = new Date();
  d.setHours(h, m + minutos, 0, 0);
  return d.toTimeString().slice(0, 5);
};

export default function VetAgendaDia() {
  const [fecha, setFecha] = useState(todayStr());
  const [slots, setSlots] = useState([]);

  const [slotParaAsignar, setSlotParaAsignar] = useState(null);
  const [citaParaReprogramar, setCitaParaReprogramar] = useState(null);

  const [vetId, setVetId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // para forzar recarga desde backend después de crear / reprogramar
  const [reloadAgenda, setReloadAgenda] = useState(0);

  // ---- calendario tira ----
  const [weekOffset, setWeekOffset] = useState(0); // días desde hoy

  const upcomingDays = useMemo(() => {
    const base = dayjs().add(weekOffset, "day");
    return Array.from({ length: 7 }, (_, i) => {
      const d = base.add(i, "day");
      return {
        value: d.format("YYYY-MM-DD"),
        dia: d.format("DD"),
        dow: d.format("ddd"),
      };
    });
  }, [weekOffset]);

  const currentMonthLabel = useMemo(
    () => dayjs().add(weekOffset, "day").format("MMM YYYY"),
    [weekOffset]
  );

  const handleSelectDia = (value) => setFecha(value);

  const handleWeekNav = (direction) =>
    setWeekOffset((prev) => prev + (direction === "next" ? 7 : -7));

  // ---- modal confirmar cita + box ----
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [citaAConfirmar, setCitaAConfirmar] = useState(null);
  const [boxConfirm, setBoxConfirm] = useState("");
  const [savingConfirm, setSavingConfirm] = useState(false);

  const abrirConfirmar = (slot) => {
    if (!slot.citaId) return;
    setCitaAConfirmar(slot);
    setBoxConfirm(slot.box || "");
    setShowConfirmModal(true);
  };

  const cerrarConfirmar = () => {
    setShowConfirmModal(false);
    setCitaAConfirmar(null);
    setBoxConfirm("");
  };

  const handleConfirmarCita = async (e) => {
    e.preventDefault();
    if (!citaAConfirmar) return;

    setSavingConfirm(true);
    try {
      await confirmarCita(citaAConfirmar.citaId, {
        estado: "confirmada",
        box: boxConfirm || null,
      });

      // actualizar estado local del slot
      setSlots((prev) =>
        prev.map((s) =>
          s.id === citaAConfirmar.id
            ? { ...s, estadoCita: "confirmada", box: boxConfirm || null }
            : s
        )
      );
      cerrarConfirmar();
    } catch (err) {
      console.error("Error confirmando cita:", err);
      setError("No se pudo confirmar la cita.");
    } finally {
      setSavingConfirm(false);
    }
  };

  // 1) obtener perfil para saber vetId
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await getUserProfile();
        if (res.data?.id) setVetId(res.data.id);
      } catch (err) {
        console.error("Error obteniendo perfil:", err);
        setError("No se pudo obtener la información del veterinario.");
      }
    };
    fetchUser();
  }, []);

  // 2) cargar agenda del día (disponibilidad + citas) SIEMPRE desde backend
  useEffect(() => {
    if (!vetId) return;

    const fetchAgendaDia = async () => {
      setLoading(true);
      setError("");
      try {
        const [dispRes, citasRes] = await Promise.all([
          getDisponibilidad({
            veterinario_id: vetId,
            fecha,
            duracion: 30,
            box: "", // sin filtro de box aquí
          }),
          getCitas({ fecha }),
        ]);

        const libres = dispRes?.data?.slots || [];

        const rawCitas = Array.isArray(citasRes.data)
          ? citasRes.data
          : Array.isArray(citasRes.data?.results)
          ? citasRes.data.results
          : [];

        const citas = rawCitas.map((c) => {
          const d = new Date(c.inicio);
          const horaInicio = d.toTimeString().slice(0, 5);
          const estadoCita = c.estado || "pendiente";

          return {
            ...c,
            horaInicio,
            horaFin: sumarMinutos(horaInicio, 30),
            estadoCita,
          };
        });

        const horasSet = new Set();
        libres.forEach((h) => horasSet.add(h));
        citas.forEach((c) => horasSet.add(c.horaInicio));
        const horasOrdenadas = Array.from(horasSet).sort();

        const nuevosSlots = horasOrdenadas.map((hora, idx) => {
          const cita = citas.find((c) => c.horaInicio === hora);

          if (cita) {
            const estadoCita = cita.estadoCita;
            const paciente =
              cita.cliente_nombre ||
              cita.cliente?.nombre_completo ||
              cita.cliente?.nombre ||
              null;
            const mascotaNombre =
              cita.mascota_nombre || cita.mascota?.nombre || null;

            return {
              id: cita.id || idx + 1,
              horaInicio: hora,
              horaFin: sumarMinutos(hora, 30),
              // para resumen tratamos confirmada y pendiente como "ocupada"
              estado:
                estadoCita === "cancelada" ? "cancelada" : "ocupada",
              estadoCita,
              paciente,
              mascota: mascotaNombre,
              citaId: cita.id,
              box: cita.box || cita.box_nombre || "",
            };
          }

          // slot libre
          return {
            id: `libre-${idx}`,
            horaInicio: hora,
            horaFin: sumarMinutos(hora, 30),
            estado: "libre",
            estadoCita: null,
            paciente: null,
            mascota: null,
            citaId: null,
            box: "",
          };
        });

        setSlots(nuevosSlots);
      } catch (err) {
        console.error("Error cargando agenda del día:", err);
        setError("No se pudo cargar la agenda para esa fecha.");
        setSlots([]);
      } finally {
        setLoading(false);
      }
    };

    fetchAgendaDia();
  }, [fecha, vetId, reloadAgenda]); // <--- se recarga cuando cambiamos reloadAgenda

  const slotsOrdenados = useMemo(
    () => [...slots].sort((a, b) => a.horaInicio.localeCompare(b.horaInicio)),
    [slots]
  );



  const handleAsignarConfirm = (payload) => {

    // { slot_id, cliente_id, cliente_nombre, mascota_id, mascota_nombre, motivo, box }

    setSlots((prev) =>
      prev.map((s) =>
        s.id === payload.slot_id
          ? {
              ...s,
              estado: "ocupada",
              estadoCita: "pendiente",
              paciente: payload.cliente_nombre || s.paciente,
              mascota: payload.mascota_nombre || s.mascota,
              box: payload.box || s.box,
            }
          : s
      )
    );
  };

  const handleReprogramarConfirm = (payload) => {
    setSlots((prev) =>
      prev.map((s) =>
        s.id === payload.id
          ? {
              ...s,
              horaInicio: payload.nueva_hora,
              horaFin: payload.nueva_hora,
            }
          : s
      )
    );
  };

  const handleCancelarSlot = (slotId) => {
    setSlots((prev) =>
      prev.map((s) =>
        s.id === slotId
          ? { ...s, estado: "cancelada", estadoCita: "cancelada" }
          : s
      )
    );
  };

  return (
    <LayoutVet>
      <div className="space-y-8">
        {/* Encabezado */}
        <section className="flex flex-col gap-3">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <p className="text-xs font-semibold tracking-[0.18em] text-sky-600 uppercase">
                Vetyon · Veterinario
              </p>
              <h1 className="mt-1 text-2xl font-bold text-slate-900">
                Agenda del día
              </h1>
              <p className="text-sm text-slate-500 mt-1">
                Revisa tus horas disponibles, ocupadas y canceladas para la
                fecha seleccionada.
              </p>
              {error && (
                <p className="mt-2 text-xs text-rose-500">{error}</p>
              )}
            </div>

            <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700">
              <CalendarDays size={18} className="text-sky-600" />
              <span>{dayjs(fecha).format("dddd DD [de] MMMM YYYY")}</span>
            </div>
          </div>

          {/* Calendario tira */}
          <div className="flex flex-col items-center gap-2">
            <span className="text-xs font-medium text-slate-600 uppercase tracking-wide">
              Selecciona una fecha
            </span>

            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={() => handleWeekNav("prev")}
                className="p-1 rounded-full border border-slate-300 text-slate-600 hover:bg-slate-50"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>

              <div className="flex flex-col items-center">
                <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wide mb-1">
                  {currentMonthLabel}
                </span>

                <div className="flex gap-1 overflow-x-auto pb-1 max-w-xs md:max-w-md">
                  {upcomingDays.map((d) => (
                    <button
                      key={d.value}
                      type="button"
                      onClick={() => handleSelectDia(d.value)}
                      className={
                        "flex flex-col items-center min-w-[3rem] px-2 py-1 rounded-lg border text-[11px] " +
                        (fecha === d.value
                          ? "bg-sky-600 text-white border-sky-600"
                          : "bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100")
                      }
                    >
                      <span className="uppercase tracking-wide text-[10px]">
                        {d.dow}
                      </span>
                      <span className="text-sm font-semibold">
                        {d.dia}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleWeekNav("next")}
                className="p-1 rounded-full border border-slate-300 text-slate-600 hover:bg-slate-50"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </section>

        {/* Contenido principal */}
        <section className="grid grid-cols-1 lg:grid-cols-[1.4fr,1fr] gap-6">
          {/* Slots */}
          <div className="rounded-2xl bg-white shadow-sm border border-slate-100 p-4 md:p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-900">
                  Horas del día
                </p>
                <p className="text-xs text-slate-500">
                  Basadas en tu disponibilidad recurrente.
                </p>
              </div>
            </div>

            <div className="space-y-2">
              {loading && (
                <p className="text-xs text-slate-500">
                  Cargando agenda del día...
                </p>
              )}

              {!loading &&
                slotsOrdenados.map((slot) => (
                  <SlotCard
                    key={slot.id}
                    slot={slot}
                    onAsignar={() => setSlotParaAsignar(slot)}
                    onReprogramar={() => {
                      if (!slot.citaId) return;
                      setCitaParaReprogramar({
                        id: slot.citaId,
                        inicio: `${fecha}T${slot.horaInicio}`,
                        box: slot.sala || slot.box || "",
                      });
                    }}
                    onCancelar={() => handleCancelarSlot(slot.id)}
                    onConfirmar={() => abrirConfirmar(slot)}
                  />
                ))}
              {!loading && slotsOrdenados.length === 0 && (
                <p className="text-xs text-slate-500">
                  No hay horas generadas para esta fecha.
                </p>
              )}
            </div>
          </div>

          {/* Resumen */}
          <div className="rounded-2xl bg-whiteshadow-sm border border-slate-100 p-4 md:p-5 space-y-4">
            <p className="text-sm font-semibold text-slate-900">
              Resumen del día
            </p>
            <ul className="space-y-2 text-xs text-slate-600">
              <li>
                • Horas libres:{" "}
                {slots.filter((s) => s.estado === "libre").length}
              </li>
              <li>
                • Horas ocupadas:{" "}
                {slots.filter((s) => s.estado === "ocupada").length}
              </li>
              <li>
                • Horas canceladas:{" "}
                {slots.filter((s) => s.estado === "cancelada").length}
              </li>
            </ul>
            <p className="text-[11px] text-slate-400">
              Esta vista se alimenta de tus horarios, bloqueos y citas
              almacenadas en el backend.
            </p>
          </div>
        </section>
      </div>

      {/* Modal crear cita: al confirmar solo recargamos desde backend */}
      <ModalCrearCita
        open={!!slotParaAsignar}
        slot={slotParaAsignar}
        onClose={() => setSlotParaAsignar(null)}
        onConfirm={handleAsignarConfirm}
      />

      <ModalReprogramarCita
        open={!!citaParaReprogramar}
        cita={citaParaReprogramar}
        vetId={vetId}
        onClose={() => setCitaParaReprogramar(null)}
        onConfirm={({ id, nueva_fecha, nueva_hora }) => {
          setSlots((prev) =>
            prev.map((s) =>
              s.citaId === id
                ? {
                    ...s,
                    horaInicio: nueva_hora,
                    horaFin: sumarMinutos(nueva_hora, 30),
                  }
                : s
            )
          );
        }}
      />

      {/* Modal confirmar cita + sala */}
      {showConfirmModal && citaAConfirmar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white shadow-xl border border-slate-200">
            <div className="px-5 py-4 border-b border-slate-100">
              <p className="text-sm font-semibold text-slate-900">
                Confirmar cita
              </p>
              <p className="mt-1 text-xs text-slate-500">
                {citaAConfirmar.horaInicio} - {citaAConfirmar.horaFin}
              </p>
            </div>

            <form onSubmit={handleConfirmarCita} className="px-5 py-4 space-y-3">
              <div>
                <label className="text-xs font-medium text-slate-700">
                  Sala / Box asignado
                </label>
                <input
                  type="text"
                  value={boxConfirm}
                  onChange={(e) => setBoxConfirm(e.target.value)}
                  placeholder="BOX-1, BOX-2..."
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  required
                />
              </div>

              <p className="text-[11px] text-slate-500">
                Al confirmar la cita quedará marcada como{" "}
                <span className="font-semibold">confirmada</span> y se guardará
                la sala asignada.
              </p>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 mt-2">
                <button
                  type="button"
                  onClick={cerrarConfirmar}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={savingConfirm}
                  className="rounded-xl bg-emerald-500 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-600 disabled:opacity-60"
                >
                  {savingConfirm ? "Confirmando..." : "Confirmar cita"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </LayoutVet>
  );
}
